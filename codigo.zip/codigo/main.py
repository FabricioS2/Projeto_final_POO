import os
import random
import math
import pygame
from os import listdir
from janela import Janela


# Exemplo de utilização
if __name__ == "__main__":
    janela = Janela()   
    janela.instanciar_janela()