import tkinter as tk
import pygame
from tela_de_fundo import TelaDeFundo
from jogador import Jogador

class Janela():
    def __init__(self):
        self.__largura, self.__altura = self.obter_informacoes_monitor()
        self.__fps = 60
        

    def get_largura(self):
        return self.__largura
    
    def get_altura(self):
        return self.__altura
    
    def get_fps(self):
        return self.__fps
    
    def get_velocidade_jogador(self):
        return self.__velocidade_jogador

    def iniciar_janela(self):
        janela = pygame.display.set_mode((self.get_largura(), self.get_altura()))
        return janela

    def instanciar_janela(self):
        janela = self.iniciar_janela()
        relogio = pygame.time.Clock()
        tela_de_funfo = TelaDeFundo()
        backgroun, bg_tela = tela_de_funfo.get_tela_de_fundo("Blue.png", self.get_largura(), self.get_altura())
            
        jogador = Jogador(100,100,50,50)
        pygame.init()
        run = True

        while run:
            relogio.tick(self.get_fps())
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                    break

            jogador.loop_jogador(self.get_fps())
            jogador.mapear_teclas()
            tela_de_funfo.desenhar_tela(janela, backgroun, bg_tela, jogador)

        pygame.quit()
        quit()

    def obter_informacoes_monitor(self):
        root = tk.Tk()
        largura = root.winfo_screenwidth()
        altura = root.winfo_screenheight()
        root.destroy()
        
        return int(largura - (largura * 0.2)), int(altura - (altura * 0.2))
