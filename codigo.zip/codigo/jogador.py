import pygame
from sprite import SpriteJogo

class Jogador(SpriteJogo):
    cor = (255,0,0)
    def __init__(self,x,y,largura,altura):
        super().__init__()
        self.rect = pygame.Rect(x,y,largura,altura)
        self.x_vel = 0
        self.y_vel = 0
        self.mask = None
        self.velocidade_jogador = 5
        self.velocidade_de_caida = 1
        self.gravidade =1 
        self.sprite = self.carregar_sprite("MainCharacters","NinjaFrog",32,32,True  )

    def mover(self,distancia_x,distancia_y):
        self.rect.x += distancia_x
        self.rect.y += distancia_y

    def mover_esquerda(self,vel):
        self.x_vel = -vel
        if self.direcao == "esquerda":
            self.direcao = "esquerda"
            self.contador_animacao = 0

    def mover_direita(self,vel):
        self.x_vel = vel
        if self.direcao == "direita":
            self.direcao = "direita"
            self.contador_animacao = 0

    def loop_jogador(self,fps=60):
        self.y_vel += min(1,(self.velocidade_de_caida/fps) * self.gravidade)
        self.mover(self.x_vel,self.y_vel)

        self.velocidade_de_caida += 1

    def inicializar_jogador(self,janela):
        self.sprite = self.sprite["idle_" + self.direcao][0]
        janela.blit(self.sprite,(self.rect.x,self.rect.y))
    
    def mapear_teclas(self):
        tecla = pygame.key.get_pressed()

        self.x_vel = 0

        if tecla[pygame.K_LEFT]:
            self.mover_esquerda(self.velocidade_jogador)
        elif tecla[pygame.K_RIGHT]:
            self.mover_direita(self.velocidade_jogador)

    

