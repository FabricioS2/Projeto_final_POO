import pygame
from os.path import isfile, join
from os import listdir


class SpriteJogo(pygame.sprite.Sprite):
    def __init__(self):
        self.direcao = "esquerda"
        self.contador_animacao = 0

    def inverter(self,sprites):
        return [pygame.transform.flip(sprite,True,False) for sprite in sprites]

    
    def carregar_sprite(self,diretorio1,diretorio2,largura,altura,direcao = False):
        caminho = join("assets",diretorio1,diretorio2)
        imagems = [f for f in listdir(caminho) if isfile(join(caminho,f))]

        todos_os_sprites = {}


        for imagem in imagems:
            folha_sprite = pygame.image.load(join(caminho,imagem)).convert_alpha()

            sprite = []

            for i in range(folha_sprite.get_width()//largura):
                superfice = pygame.Surface((largura,altura),pygame.SRCALPHA,32)
                rect = pygame.Rect(i * largura,0,largura,altura)
                superfice.blit(folha_sprite,(0,0),rect)
                sprite.append(pygame.transform.scale2x(superfice))

            if direcao:
                todos_os_sprites[imagem.replace(".png","")+"_direita"] = sprite
                todos_os_sprites[imagem.replace(".png","")+"_esquerda"] = self.inverter(sprite)
            else:
                todos_os_sprites[imagem.replace(".png","")+"_direita"] = sprite

        return todos_os_sprites