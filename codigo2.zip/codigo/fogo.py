from colicao import Mixin_colicao
import pygame
from sprite import SpriteJogo
from objeto import Objeto

# class Fogo(Objeto,SpriteJogo):
#     def __init__(self, x, y, largura, altura):
#         super().__init__(x, y, largura, altura)


class Fogo(Objeto,SpriteJogo):
    

    def __init__(self, x, y, largura, altura):
        super().__init__(x, y, largura, altura)
        self.fogo = self.carregar_sprite("Traps", "Fire", largura, altura)
        self.imagem = self.fogo["off"][0]
        self.mascara = pygame.mask.from_surface(self.imagem)
        self.contagem_animacao = 0
        self.nome_animacao = "off"
        self.atraso_animacao = 3

    def ligar(self):
        self.nome_animacao = "on"

    def desligar(self):
        self.nome_animacao = "off"

    def loop(self):
        sprites = self.fogo[self.nome_animacao]
        indice_sprite = (self.contagem_animacao //
                         self.atraso_animacao) % len(sprites)
        self.imagem = sprites[indice_sprite]
        self.contagem_animacao += 1

        self.rect = self.imagem.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mascara = pygame.mask.from_surface(self.imagem)

        if self.contagem_animacao // self.atraso_animacao > len(sprites):
            self.contagem_animacao = 0

